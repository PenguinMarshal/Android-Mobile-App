package com.example.geoquiz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.geoquiz.databinding.ActivityMainBinding

private const val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val quizViewModel: QuizViewModel by viewModels()

    private val cheatLauncher: ActivityResultLauncher<Intent> = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            quizViewModel.isCheater =
                result.data?.getBooleanExtra(EXTRA_ANSWER_SHOWN, false) ?: false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate(Bundle?) called")

        // Initialize binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "Got a QuizViewModel: $quizViewModel")

        // Set up the trueButton click listener
        binding.trueButton.setOnClickListener {
            checkAnswer(true)
        }

        // Set up the falseButton click listener
        binding.falseButton.setOnClickListener {
            checkAnswer(false)
        }

        // Set up the nextButton click listener
        binding.nextButton.setOnClickListener {
            quizViewModel.moveToNext()
            updateQuestion()
        }

        // Set up the cheatButton click listener
        binding.cheatButton.setOnClickListener {
            val answerIsTrue = quizViewModel.currentQuestionAnswer
            val intent = CheatActivity.newIntent(this, answerIsTrue)
            cheatLauncher.launch(intent)
        }

        binding.previousButton.setOnClickListener {
            quizViewModel.moveToPrevious()
            updateQuestion()
        }

        // Update the question text at the start
        updateQuestion()
    }

    private fun updateQuestion() {
        val questionTextResId = quizViewModel.currentQuestionText
        binding.questionTextView.setText(questionTextResId)

        // Re-enable buttons if the question has not been answered
        if (!quizViewModel.answeredQuestions[quizViewModel.currentIndex]) {
            binding.trueButton.isEnabled = true
            binding.falseButton.isEnabled = true
        } else {
            // Keep the buttons disabled if the question was already answered
            binding.trueButton.isEnabled = false
            binding.falseButton.isEnabled = false
        }
    }


    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = quizViewModel.currentQuestionAnswer

        // Prevent answering the question again
        if (quizViewModel.answeredQuestions[quizViewModel.currentIndex]) {
            Toast.makeText(this, R.string.already_answered_toast, Toast.LENGTH_SHORT).show()
            return
        }

        if (userAnswer == correctAnswer) {
            quizViewModel.correctAnswers++
        }

        val messageResId = when {
            quizViewModel.isCheater -> R.string.judgment_toast
            userAnswer == correctAnswer -> R.string.correct_toast
            else -> R.string.incorrect_toast
        }

        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()

        // Mark the question as answered
        quizViewModel.answeredQuestions[quizViewModel.currentIndex] = true

        // Disable the True/False buttons after answering
        binding.trueButton.isEnabled = false
        binding.falseButton.isEnabled = false

        if (quizViewModel.currentIndex == quizViewModel.questionBank.size - 1) {
            val scoreMessage = getString(R.string.score_message, quizViewModel.correctAnswers, quizViewModel.questionBank.size)
            Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show()
        }
    }
}
