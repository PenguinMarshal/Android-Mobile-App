package com.bignerdranch.android.criminalintent

import android.app.Dialog
import android.app.TimePickerDialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import java.util.*

class TimePickerFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        return TimePickerDialog(requireContext(), { _, selectedHour, selectedMinute ->
            val result = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, selectedHour)
                set(Calendar.MINUTE, selectedMinute)
            }.time
            sendResult(result)
        }, hour, minute, true)
    }

    private fun sendResult(time: Date) {
        // Send the selected time back to the CrimeDetailFragment
        val result = Bundle().apply {
            putSerializable(BUNDLE_KEY_TIME, time)
        }
        parentFragmentManager.setFragmentResult(REQUEST_KEY_TIME, result)
    }

    companion object {
        const val REQUEST_KEY_TIME = "timeRequest"
        const val BUNDLE_KEY_TIME = "timeBundle"
    }
}
